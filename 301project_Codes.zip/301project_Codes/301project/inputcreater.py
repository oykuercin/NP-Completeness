import random



measurement = 1
while(measurement < 11):
    i = 10
    while(i <= 100):
        f = open("input"+str(measurement)+"-"+str(i)+".txt","w")
        f.write(str(i))
        f.write("\n")
        count = 0
        count2 = 0
        iterate = True
        while(count < i):
            rand = random.randint(0,i)
            count2 = 0
            while(count2 < rand):
                f.write(str(random.randint(1,i)))
                f.write("\n")
                count2 += 1
            f.write("0")
            f.write("\n")
            count += 1
        i += 10        
    measurement += 1   
        

