# MLST
An implementation of 3-approximation Maximum Leaf Spanning Trees algorithm
