# -*- coding: utf-8 -*-
"""
Created on Thu Dec 19 02:36:02 2019

@author: sansalbakkal
"""
import random

import matplotlib.pyplot as plt
import numpy as np
import statistics
data = [
  [10, [0.0744502,0.0557414,0.1115042,0.06,0.0209,0.04,0.03,0.03,0.03,0.03]],
  [20, [0.289556,0.190957,0.22035,0.21480,0.214,0.203,0.19,0.17,0.17,0.26]],
  [30, [0.435367,0.454915,0.363504,0.49415,0.3874,0.524,0.36,0.38,0.35,0.38]],
  [40,[0.576105,0.505395,0.46458,0.67916,0.63,0.56,0.65,0.57,0.59,0.60]],
  [50,[0.806035,0.826218,0.751687,0.9366,1,0.76,0.86,0.971,0.85,0.99,]],
  [60,[1.29015,1.48063,1.03922,1.17489,1.1517,1.26,1.29,1.35,1.25,1.25]],
  [70,[1.45324,1.55241,1.55398,2.36924,1.545,1.69,1.86,1.99,1.98,1.90]],
  [80,[1.74509,1.85161,2.42799,2.37,2.511,2.31,2.32,2.413,2.16,2.22]],
  [90,[2.36187,2.51634,2.83763,2.959,2.62,2.74,3.24,3.02,2.66,2.68]],
  [100,[2.63978,3.19934,2.96248,3.10,3.38,3.67,3.258,3.2,3.81,3.90]]
]


size10 = 0.0744502 + 0.0557414 + 0.1115042 + 0.06 + 0.0209 + 0.04 + 0.03 + 0.03 + 0.03 + 0.03
size20 = 0.289556 + 0.190957 + 0.22035 + 0.21480 + 0.214 + 0.203 + 0.19 + 0.17 + 0.17 + 0.26
size30 = 0.435367 + 0.454915 + 0.363504 + 0.49415 + 0.3874 + 0.524 + 0.36 + 0.38 + 0.35 + 0.38
size40 = 0.576105 +0.505395 + 0.46458 + 0.67916 + 0.63 + 0.56 + 0.65 + 0.57 + 0.59 + 0.60
size50 = 0.806035 + 0.826218 + 0.751687 + 0.9366 + 1 + 0.76 + 0.86 + 0.971 + 0.85 + 0.99
size60 = 1.29015 + 1.48063 + 1.03922 + 1.17489 + 1.1517 + 1.26 + 1.29 + 1.35 + 1.25 + 1.25
size70 = 1.45324 + 1.55241 + 1.55398 + 2.36924 + 1.545 + 1.69 + 1.86 + 1.99 + 1.98 + 1.90
size80 = 1.74509 + 1.85161 + 2.42799 + 2.37 + 2.511 + 2.31 + 2.32 + 2.413 + 2.16 + 2.22
size90 = 2.36187 + 2.51634 + 2.83763 + 2.959 + 2.62 + 2.74 + 3.24 + 3.02 + 2.66 + 2.68
size100 = 2.63978 + 3.19934 + 2.96248 + 3.10 + 3.38 + 3.67 + 3.258 + 3.2 + 3.81 + 3.90

allposible = (size10 + size30 + size20 + size40 + size50 + size60 + size70 + size80 + size90 + size100)/100
print("M" + str(allposible))
avgsize10 = size10/10


print("Size 10: " + str(avgsize10))
avgsize20 = size20/10
print("Size 20: " + str(avgsize20))
avgsize30 = size30/10
print("Size 30: " + str(avgsize30))
avgsize40 = size40/10
print("Size 40: " + str(avgsize40))
avgsize50 = size50/10
print("Size 50: " + str(avgsize50))
avgsize60 = size60/10
print("Size 60: " + str(avgsize60))
avgsize70 = size70/10
print("Size 70: " + str(avgsize70))
avgsize80 = size80/10
print("Size 80: " + str(avgsize80))
avgsize90 = size90/10
print("Size 90: " + str(avgsize90))
avgsize100 = size100/10
print("Size 100: " + str(avgsize100))



size10sd = [0.0744502,0.0557414,0.1115042,0.06,0.0209,0.04,0.03,0.03,0.03,0.03]
size10sd = statistics.stdev(size10sd)
print("Sd for size 10 : "+str(size10sd))

size20sd = [0.289556,0.190957,0.22035,0.21480,0.214,0.203,0.19,0.17,0.17,0.26]
size20sd = statistics.stdev(size20sd)
print("Sd for size 20 : "+str(size20sd))


size30sd = [0.435367,0.454915,0.363504,0.49415,0.3874,0.524,0.36,0.38,0.35,0.38]
size30sd = statistics.stdev(size30sd)
print("Sd for size 30 : "+str(size30sd))


size40sd = [0.576105,0.505395,0.46458,0.67916,0.63,0.56,0.65,0.57,0.59,0.60]
size40sd = statistics.stdev(size40sd)
print("Sd for size 40 : "+str(size40sd))



size50sd = [0.806035,0.826218,0.751687,0.9366,1,0.76,0.86,0.971,0.85,0.99,]
size50sd = statistics.stdev(size50sd)
print("Sd for size 50 : "+str(size50sd))


size60sd = [1.29015,1.48063,1.03922,1.17489,1.1517,1.26,1.29,1.35,1.25,1.25]
size60sd = statistics.stdev(size60sd)
print("Sd for size 60 : "+str(size60sd))


size70sd = [1.45324,1.55241,1.55398,2.36924,1.545,1.69,1.86,1.99,1.98,1.90]
size70sd = statistics.stdev(size70sd)
print("Sd for size 70 : "+str(size70sd))


size80sd = [1.74509,1.85161,2.42799,2.37,2.511,2.31,2.32,2.413,2.16,2.22]
size80sd = statistics.stdev(size80sd)
print("Sd for size 80 : "+str(size80sd))


size90sd = [2.36187,2.51634,2.83763,2.959,2.62,2.74,3.24,3.02,2.66,2.68]
size90sd = statistics.stdev(size90sd)
print("Sd for size 90 : "+str(size90sd))


size100sd = [2.63978,3.19934,2.96248,3.10,3.38,3.67,3.258,3.2,3.81,3.90]
size100sd = statistics.stdev(size100sd)
print("Sd for size 100 : "+str(size100sd))

sm10 = size10sd / 10
print("Calculate Estimated Standard Error for 10 input: " + str(sm10))
sm20 = size20sd / 10
print("Calculate Estimated Standard Error for 20 input: " + str(sm20))
sm30 = size30sd / 10
print("Calculate Estimated Standard Error for 30 input: " + str(sm30))
sm40 = size40sd / 10
print("Calculate Estimated Standard Error for 40 input: " + str(sm40))
sm50 = size50sd / 10
print("Calculate Estimated Standard Error for 50 input: " + str(sm50))
sm60 = size60sd / 10
print("Calculate Estimated Standard Error for 60 input: " + str(sm60))
sm70 = size70sd / 10
print("Calculate Estimated Standard Error for 70 input: " + str(sm70))
sm80 = size80sd / 10
print("Calculate Estimated Standard Error for 80 input: " + str(sm80))
sm90 = size90sd / 10
print("Calculate Estimated Standard Error for 90 input: " + str(sm90))
sm100 = size100sd / 10
print("Calculate Estimated Standard Error for 100 input: " + str(sm100))


t= 1.984
confidencelevel = 95
lowerlevel10 = avgsize10 - t*sm10
upperlevel10 = avgsize10 + t*sm10
print("Confidence interval level for size 10: "+ str(lowerlevel10) + "," + str(upperlevel10))
lowerlevel20 = avgsize20 - t*sm20
upperlevel20 = avgsize20 + t*sm20
print("Confidence interval level for size 20: " +str(lowerlevel20) + "," + str(upperlevel20))
lowerlevel30 = avgsize30 - t*sm30
upperlevel30 = avgsize30 + t*sm30
print("Confidence interval level for size 30: " +str(lowerlevel30) + "," + str(upperlevel30))
lowerlevel40 = avgsize40 - t*sm40
upperlevel40 = avgsize40 + t*sm40
print("Confidence interval level for size 40: " +str(lowerlevel40) + "," + str(upperlevel40))
lowerlevel50 = avgsize50 - t*sm50
upperlevel50 = avgsize50 + t*sm50
print("Confidence interval level for size 50: "+ str(lowerlevel50) + "," + str(upperlevel50))
lowerlevel60 = avgsize60 - t*sm60
upperlevel60 = avgsize60 + t*sm60
print("Confidence interval level for size 60: " +str(lowerlevel60) + "," + str(upperlevel60))
lowerlevel70 = avgsize70 - t*sm70
upperlevel70 = avgsize70 + t*sm70
print("Confidence interval level for size 70: " +str(lowerlevel70) + "," + str(upperlevel70))
lowerlevel80 = avgsize80 - t*sm80
upperlevel80 = avgsize80 + t*sm80
print("Confidence interval level for size 80: " +str(lowerlevel80) + "," + str(upperlevel80))
lowerlevel90 = avgsize90 - t*sm90
upperlevel90 = avgsize90 + t*sm90
print("Confidence interval level for size 90: " +str(lowerlevel90) + "," + str(upperlevel90))
lowerlevel100 = avgsize100 - t*sm100
upperlevel100 = avgsize100 + t*sm100
print("Confidence interval level for size 100: " +str(lowerlevel100) + "," + str(upperlevel100))



t= 1.290
confidencelevel = 80
lowerlevel10 = avgsize10 - t*sm10
upperlevel10 = avgsize10 + t*sm10
print("Confidence interval level for size 10: "+ str(lowerlevel10) + "," + str(upperlevel10))
lowerlevel20 = avgsize20 - t*sm20
upperlevel20 = avgsize20 + t*sm20
print("Confidence interval level for size 20: " +str(lowerlevel20) + "," + str(upperlevel20))
lowerlevel30 = avgsize30 - t*sm30
upperlevel30 = avgsize30 + t*sm30
print("Confidence interval level for size 30: " +str(lowerlevel30) + "," + str(upperlevel30))
lowerlevel40 = avgsize40 - t*sm40
upperlevel40 = avgsize40 + t*sm40
print("Confidence interval level for size 40: " +str(lowerlevel40) + "," + str(upperlevel40))
lowerlevel50 = avgsize50 - t*sm50
upperlevel50 = avgsize50 + t*sm50
print("Confidence interval level for size 50: "+ str(lowerlevel50) + "," + str(upperlevel50))
lowerlevel60 = avgsize60 - t*sm60
upperlevel60 = avgsize60 + t*sm60
print("Confidence interval level for size 60: " +str(lowerlevel60) + "," + str(upperlevel60))
lowerlevel70 = avgsize70 - t*sm70
upperlevel70 = avgsize70 + t*sm70
print("Confidence interval level for size 70: " +str(lowerlevel70) + "," + str(upperlevel70))
lowerlevel80 = avgsize80 - t*sm80
upperlevel80 = avgsize80 + t*sm80
print("Confidence interval level for size 80: " +str(lowerlevel80) + "," + str(upperlevel80))
lowerlevel90 = avgsize90 - t*sm90
upperlevel90 = avgsize90 + t*sm90
print("Confidence interval level for size 90: " +str(lowerlevel90) + "," + str(upperlevel90))
lowerlevel100 = avgsize100 - t*sm100
upperlevel100 = avgsize100 + t*sm100
print("Confidence interval level for size 100: " +str(lowerlevel100) + "," + str(upperlevel100))

